#include<stdio.h>
#include<stdlib.h>
#include<dirent.h>
#include<string.h>

int main(int argc, char* argv[]){
    DIR *dir;
    struct dirent *entry;
    const char *path = ".";

    if(argc > 1){
        path = argv[1];
    }
    dir = opendir(path);
    if(dir == NULL){
        perror("There is the error wile opeing the directory\n");
        return EXIT_FAILURE;
    }
    printf("The contents of the directory are listed below: \n");
    while((entry = readdir(dir)) != NULL){
        if(strcmp(entry -> d_name, ".") != 0 && (strcmp(entry -> d_name , "..") != 0)){
            printf("%s\n", entry->d_name);
        }
    }
    closedir(dir);
    return EXIT_SUCCESS;
}