#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(int argc, char* argv[]){
    if(argc < 3){
        fprintf(stderr, "Usage: %s <source_file> <destination_directory>\n", argv[0]);
        return EXIT_FAILURE;
    }
    char destination_path[1024];
    snprintf(destination_path, sizeof(destination_path), "%s%s", argv[2], strchr(argv[1], '/') ? strchr(argv[1], '/') + 1 : argv[1]);
    FILE *source = fopen(argv[1], "rb");
    if (source == NULL) {
        perror("There is a error while opeingi the source file\n");
        return EXIT_FAILURE;
    }
    FILE *destination = fopen(destination_path, "wb");
    if (destination == NULL) {
        perror("Error opening destination file");
        fclose(source);
        return EXIT_FAILURE;
    }
    int ch;
    while ((ch = fgetc(source)) != EOF) {
        fputc(ch, destination);
    }

    fclose(source);
    fclose(destination);

    printf("%s copied to %s\n", argv[1], argv[2]);

    return EXIT_SUCCESS;
}