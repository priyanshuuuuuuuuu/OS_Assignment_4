#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
int main(int argc, char* argv[]){
    if(argc < 2){
        fprintf(stderr, "Usage &s <filename>\n");
        return EXIT_FAILURE;
    }
    FILE *file = fopen(argv[1], "r");
    if(file == NULL){
        perror("Error while opeing the file");
        return EXIT_FAILURE;
    }
    int word_count = 0;
    int in_word = 0;
    int ch;

    while((ch = fgetc(file)) != EOF){
        if(isspace(ch)){
            in_word = 0;
        }else if(!in_word){
            in_word = 1;
            word_count ++;
        }
    }
    fclose(file);

    printf("Word Count: %d\n", word_count);


    return EXIT_SUCCESS;
}