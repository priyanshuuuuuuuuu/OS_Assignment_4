#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>

int move_file(const char *source, const char *destination) {
    char dest_path[1024];
    // Extract just the filename from the source path
    const char *filename = strrchr(source, '/');
    filename = filename ? filename + 1 : source;
    
    snprintf(dest_path, sizeof(dest_path), "%s/%s", destination, filename);
    
    // Use rename for moving
    if (rename(source, dest_path) != 0) {
        // If rename fails (e.g., across different filesystems), try copy and delete
        FILE *src = fopen(source, "rb");
        if (src == NULL) {
            perror("Error opening source file");
            return -1;
        }

        FILE *dst = fopen(dest_path, "wb");
        if (dst == NULL) {
            perror("Error opening destination file");
            fclose(src);
            return -1;
        }

        int ch;
        while ((ch = fgetc(src)) != EOF) {
            fputc(ch, dst);
        }

        fclose(src);
        fclose(dst);

        // Remove the original file
        if (unlink(source) != 0) {
            perror("Error removing original file");
            return -1;
        }
    }
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <source_directory> <destination_directory>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Create destination directory if it doesn't exist
    struct stat st = {0};
    if (stat(argv[2], &st) == -1) {
        if (mkdir(argv[2], 0755) != 0) {
            perror("Error creating destination directory");
            return EXIT_FAILURE;
        }
    }

    DIR *dir;
    struct dirent *entry;

    // Open source directory
    dir = opendir(argv[1]);
    if (dir == NULL) {
        perror("Error opening source directory");
        return EXIT_FAILURE;
    }

    // Move each file in the source directory
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") != 0 && 
            strcmp(entry->d_name, "..") != 0 && 
            strcmp(entry->d_name, "main") != 0 &&  // Skip executable files
            strcmp(entry->d_name, "move") != 0 &&
            strcmp(entry->d_name, "copy") != 0 &&
            strcmp(entry->d_name, "list") != 0 &&
            strcmp(entry->d_name, "countw") != 0) {
            
            char source_path[1024];
            snprintf(source_path, sizeof(source_path), "%s/%s", argv[1], entry->d_name);

            if (move_file(source_path, argv[2]) != 0) {
                closedir(dir);
                return EXIT_FAILURE;
            }
        }
    }

    // Close directory
    closedir(dir);

    // Print success message
    printf("Moved contents of %s to %s\n", argv[1], argv[2]);

    return EXIT_SUCCESS;
}