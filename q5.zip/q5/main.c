#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pids[4]; // Array to store PIDs for 4 child processes
    int status;

    // Create three child processes for list, countw, and copy
    for (int i = 0; i < 3; i++) {
        pids[i] = fork();

        if (pids[i] < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (pids[i] == 0) {
            switch (i) {
                case 0: // Run "list" executable
                    execl("./list", "list", "..", NULL);
                    perror("exec list failed");
                    exit(EXIT_FAILURE);
                case 1: // Run "countw" executable
                    execl("./countw", "countw", "Makefile", NULL);
                    perror("exec countw failed");
                    exit(EXIT_FAILURE);
                case 2: // Run "copy" executable
                    execl("./copy", "copy", "list.c", "..", NULL);
                    perror("exec copy failed");
                    exit(EXIT_FAILURE);
            }
        }
    }

    // Create a child process for "move"
    pids[3] = fork();
    if (pids[3] < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pids[3] == 0) {
        execl("./move", "move", ".", "q5_files", NULL);
        perror("exec move failed");
        exit(EXIT_FAILURE);
    }

    // Wait for all child processes to finish
    for (int i = 0; i < 4; i++) {
        if (waitpid(pids[i], &status, 0) < 0) {
            perror("waitpid");
            exit(EXIT_FAILURE);
        }
        if (WIFEXITED(status)) {
            printf("Process %d exited with status %d\n", pids[i], WEXITSTATUS(status));
        } else {
            printf("Process %d did not exit cleanly\n", pids[i]);
        }
    }

    return EXIT_SUCCESS;
}
